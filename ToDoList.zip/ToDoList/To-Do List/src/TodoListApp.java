import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.io.*; // For serialization

public class TodoListApp extends JFrame {
    private ArrayList<Task> tasks;
    private DefaultListModel<Task> listModel;
    private JList<Task> taskList;
    private JTextField taskField;
    private JComboBox<String> priorityCombo;
    private JButton addButton, editButton, deleteButton, completeButton;
    private String userName;

    // Cores para as prioridades
    private static final Color HIGH_PRIORITY = new Color(255, 200, 200);
    private static final Color MEDIUM_PRIORITY = new Color(255, 255, 200);
    private static final Color LOW_PRIORITY = new Color(200, 255, 200);

    public TodoListApp() {
        // Configuração básica da janela
        setTitle("To-Do List");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Inicialização das estruturas de dados
        tasks = new ArrayList<>();
        listModel = new DefaultListModel<>();
        
        // Solicitar nome do usuário
        userName = JOptionPane.showInputDialog(this, "Digite seu nome:", "Bem-vindo!", JOptionPane.PLAIN_MESSAGE);
        if (userName == null || userName.trim().isEmpty()) {
            userName = "Usuário";
        }
        
        // Configurar o layout principal
        setLayout(new BorderLayout(10, 10));
        
        // Painel de título personalizado
        JPanel titlePanel = createTitlePanel();
        add(titlePanel, BorderLayout.NORTH);
        
        // Painel central com a lista de tarefas
        JPanel centerPanel = createTaskListPanel();
        add(centerPanel, BorderLayout.CENTER);
        
        // Painel inferior com controles
        JPanel bottomPanel = createControlPanel();
        add(bottomPanel, BorderLayout.SOUTH);
        
        // Adicionar margens ao redor de todos os componentes
        ((JPanel)getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }
    
    private JPanel createTitlePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        JLabel titleLabel = new JLabel("Tarefas de " + userName);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        
        panel.add(titleLabel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createTaskListPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        
        // Criar a lista com renderizador personalizado
        taskList = new JList<>(listModel);
        taskList.setCellRenderer(new TaskCellRenderer());
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Adicionar a lista a um painel de rolagem
        JScrollPane scrollPane = new JScrollPane(taskList);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(5, 5, 5, 5),
            BorderFactory.createLineBorder(Color.LIGHT_GRAY)
        ));
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createControlPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(0, 10));
        
        // Painel para adicionar tarefas
        JPanel addPanel = new JPanel(new BorderLayout(5, 0));
        addPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createEtchedBorder(), "Adicionar Tarefa", 
            TitledBorder.LEFT, TitledBorder.TOP, 
            new Font("Segoe UI", Font.BOLD, 12)
        ));
        
        taskField = new JTextField();
        taskField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        JPanel inputPanel = new JPanel(new BorderLayout(5, 0));
        
        priorityCombo = new JComboBox<>(new String[]{"Alta", "Média", "Baixa"});
        priorityCombo.setPreferredSize(new Dimension(100, 30));
        
        addButton = new JButton("Adicionar");
        addButton.setBackground(new Color(100, 180, 255));
        addButton.setForeground(Color.BLACK);
        addButton.setFocusPainted(false);
        addButton.addActionListener(e -> addTask());
        
        inputPanel.add(priorityCombo, BorderLayout.WEST);
        inputPanel.add(taskField, BorderLayout.CENTER);
        inputPanel.add(addButton, BorderLayout.EAST);
        
        addPanel.add(inputPanel, BorderLayout.CENTER);
        
        // Painel para os botões de ação
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 0));
        
        editButton = createButton("Editar", new Color(255, 180, 100));
        editButton.addActionListener(e -> editTask());
        
        deleteButton = createButton("Excluir", new Color(255, 100, 100));
        deleteButton.addActionListener(e -> deleteTask());
        
        completeButton = createButton("Concluir", new Color(100, 200, 100));
        completeButton.addActionListener(e -> completeTask());
        
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(completeButton);
        
        mainPanel.add(addPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        return mainPanel;
    }
    
    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        return button;
    }
    
    private void addTask() {
        String taskText = taskField.getText().trim();
        if (!taskText.isEmpty()) {
            String priority = (String) priorityCombo.getSelectedItem();
            Task newTask = new Task(taskText, priority);
            tasks.add(newTask);
            listModel.addElement(newTask);
            taskField.setText("");
            taskField.requestFocus();
        }
    }
    
    private void editTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Task task = listModel.getElementAt(selectedIndex);
            String newText = JOptionPane.showInputDialog(this, "Editar tarefa:", task.getDescription());
            if (newText != null && !newText.trim().isEmpty()) {
                task.setDescription(newText.trim());
                
                String[] options = {"Alta", "Média", "Baixa"};
                int priorityIndex = JOptionPane.showOptionDialog(
                    this, "Selecione a prioridade:", "Prioridade", 
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, 
                    null, options, task.getPriority()
                );
                
                if (priorityIndex != -1) {
                    task.setPriority(options[priorityIndex]);
                }
                
                taskList.repaint();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma tarefa para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void deleteTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            int confirm = JOptionPane.showConfirmDialog(
                this, "Tem certeza que deseja excluir esta tarefa?", 
                "Confirmar exclusão", JOptionPane.YES_NO_OPTION
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                tasks.remove(selectedIndex);
                listModel.remove(selectedIndex);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma tarefa para excluir.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void completeTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            Task task = listModel.getElementAt(selectedIndex);
            task.setCompleted(!task.isCompleted());
            taskList.repaint();
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma tarefa para marcar como concluída.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    // Usando a classe Task externa
    
    // Renderizador personalizado para as células da lista
    private class TaskCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof Task) {
                Task task = (Task) value;
                
                // Definir o texto
                if (task.isCompleted()) {
                    label.setText("<html><strike>" + task.getDescription() + "</strike> <font color='gray'>(" + task.getPriority() + ")</font></html>");
                } else {
                    label.setText("<html>" + task.getDescription() + " <font color='gray'>(" + task.getPriority() + ")</font></html>");
                }
                
                // Definir a cor de fundo baseada na prioridade (se não estiver selecionado)
                if (!isSelected) {
                    if (task.isCompleted()) {
                        label.setBackground(new Color(240, 240, 240));
                    } else {
                        switch (task.getPriority()) {
                            case "Alta":
                                label.setBackground(HIGH_PRIORITY);
                                break;
                            case "Média":
                                label.setBackground(MEDIUM_PRIORITY);
                                break;
                            case "Baixa":
                                label.setBackground(LOW_PRIORITY);
                                break;
                        }
                    }
                }
                
                // Adicionar um pouco de padding
                label.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            }
            
            return label;
        }
    }

    public static void main(String[] args) {
        try {
            // Usar o look and feel do sistema
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            TodoListApp app = new TodoListApp();
            app.setVisible(true);
        });
    }
}