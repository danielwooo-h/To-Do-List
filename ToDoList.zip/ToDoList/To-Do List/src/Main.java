import javax.swing.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        String nome = JOptionPane.showInputDialog("Digite seu Nome:");

        ArrayList<String> tarefas = new ArrayList<>();


        while (true) {

            String tarefa = JOptionPane.showInputDialog(null, "Digite sua Tarefa:");
            if (tarefa == null || tarefa.equalsIgnoreCase("sair")) {
                break;
            }

            String prioridade = JOptionPane.showInputDialog(null, "Digite a Prioridade da Tarefa (ex: Alta, Média, Baixa):");
            if (prioridade == null) {
                prioridade = "Não especificada";
            }

            tarefas.add(prioridade + ": " + tarefa);


            int opcao = JOptionPane.showConfirmDialog(null, "Deseja adicionar outra tarefa?", "Continuar", JOptionPane.YES_NO_OPTION);
            if (opcao != JOptionPane.YES_OPTION) {
                break;
            }
        }

        StringBuilder listafinal = new StringBuilder();
        for (int i = 0; i < tarefas.size(); i++) {
            listafinal.append((i + 1)).append(". ").append(tarefas.get(i)).append("\n");
        }


        JOptionPane.showMessageDialog(null, "Tarefas de " + nome + ":\n" + listafinal.toString());

        String excluir = JOptionPane.showInputDialog(null, "Digite a Tarefa que Deseja Excluir:");
            while (true) {
                int numero = Integer.parseInt(excluir.trim());
                if (numero >= 1 && numero <= tarefas.size())
                {
                    tarefas.remove(numero - 1);
                    JOptionPane.showMessageDialog(null, "Tarefa Excluida");
                } else {
                    JOptionPane.showMessageDialog(null, "Sair");
                    break;
                }
            }

    }
}
